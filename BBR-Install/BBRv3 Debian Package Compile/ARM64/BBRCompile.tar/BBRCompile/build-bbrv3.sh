#!/usr/bin/env bash
set -Eeuo pipefail

GIT_URL="${GIT_URL:-https://github.com/google/bbr.git}"
GIT_BRANCH="${GIT_BRANCH:-v3}"

# Kernel target architecture. For an x86_64/amd64 host building an ARM64
# kernel, keep the Docker container on linux/amd64 and cross-compile the kernel
# with ARCH=arm64 and CROSS_COMPILE=aarch64-linux-gnu-.
KARCH="${KARCH:-arm64}"
DEBARCH="${DEBARCH:-arm64}"

if [[ -z "${CROSS_COMPILE:-}" ]]; then
  case "$KARCH:$DEBARCH" in
    arm64:*|*:arm64) CROSS_COMPILE="aarch64-linux-gnu-" ;;
    *)              CROSS_COMPILE="" ;;
  esac
fi

# Do NOT use exported LOCALVERSION directly. The kernel Makefile also consumes
# LOCALVERSION from the environment, which can cause duplicated names like:
#   -bbrv3-d13-arm64-bbrv3-d13-arm64
KERNEL_LOCALVERSION="${KERNEL_LOCALVERSION:-${LOCALVERSION:--bbrv3}}"
unset LOCALVERSION

OUT="${OUT:-/out}"
CONFIG_IN="${CONFIG_IN:-}"
JOBS="${JOBS:-$(nproc)}"

mkdir -p "$OUT"

cd /build
rm -rf linux-bbrv3
rm -f ./*.deb ./*.buildinfo ./*.changes

git clone --depth=1 -b "$GIT_BRANCH" "$GIT_URL" linux-bbrv3
cd linux-bbrv3

MAKE_ARGS=(ARCH="$KARCH")

if [[ -n "${CROSS_COMPILE:-}" ]]; then
  if ! command -v "${CROSS_COMPILE}gcc" >/dev/null 2>&1; then
    echo "ERROR: ${CROSS_COMPILE}gcc not found in PATH." >&2
    echo "Install the matching cross compiler in the build image, e.g. gcc-aarch64-linux-gnu for ARM64." >&2
    exit 1
  fi
  MAKE_ARGS+=(CROSS_COMPILE="$CROSS_COMPILE")
fi

make "${MAKE_ARGS[@]}" mrproper

if [[ -n "$CONFIG_IN" && -f "$CONFIG_IN" ]]; then
  echo "Using kernel config: $CONFIG_IN"
  cp "$CONFIG_IN" .config
else
  echo "No CONFIG_IN supplied; using defconfig."
  make "${MAKE_ARGS[@]}" defconfig
fi

# Stable, portable package naming.
scripts/config --set-str LOCALVERSION "$KERNEL_LOCALVERSION"
scripts/config --disable LOCALVERSION_AUTO

# TCP congestion control.
scripts/config --enable TCP_CONG_ADVANCED

# Google BBRv3 branch:
#   CONFIG_TCP_CONG_BBR  -> tcp_bbr.c  -> "bbr"  -> BBRv3
#   CONFIG_TCP_CONG_BBR1 -> tcp_bbr1.c -> "bbr1" -> BBRv1
scripts/config --enable TCP_CONG_BBR
scripts/config --enable TCP_CONG_BBR1

# fq qdisc for BBR pacing.
scripts/config --enable NET_SCH_FQ

# Make BBRv3 the default.
scripts/config --enable DEFAULT_BBR
scripts/config --set-str DEFAULT_TCP_CONG bbr

# Avoid distro certificate-file build failures.
scripts/config --set-str SYSTEM_TRUSTED_KEYS ""
scripts/config --set-str SYSTEM_REVOCATION_KEYS ""
scripts/config --set-str SYSTEM_BLACKLIST_HASH_LIST ""
scripts/config --set-str SYSTEM_EXTRA_CERTIFICATE ""

# Do not require module signing for this portable build.
scripts/config --disable MODULE_SIG
scripts/config --disable MODULE_SIG_ALL
scripts/config --disable MODULE_SIG_FORCE
scripts/config --set-str MODULE_SIG_KEY "certs/signing_key.pem"

# Disable debug info and BTF to avoid toolchain/pahole issues.
scripts/config --disable DEBUG_INFO
scripts/config --disable DEBUG_INFO_DWARF4
scripts/config --disable DEBUG_INFO_DWARF5
scripts/config --disable DEBUG_INFO_REDUCED
scripts/config --disable DEBUG_INFO_COMPRESSED
scripts/config --disable DEBUG_INFO_SPLIT
scripts/config --disable DEBUG_INFO_BTF
scripts/config --disable DEBUG_INFO_BTF_MODULES

# Disable heavy debug/sanitizer options.
scripts/config --disable KASAN
scripts/config --disable KASAN_GENERIC
scripts/config --disable KASAN_SW_TAGS
scripts/config --disable KASAN_HW_TAGS
scripts/config --disable KCSAN
scripts/config --disable KFENCE
scripts/config --disable UBSAN
scripts/config --disable UBSAN_SANITIZE_ALL
scripts/config --disable KCOV

# Disable old Ubuntu GCC plugin options that can break upstream builds.
scripts/config --disable GCC_PLUGINS
scripts/config --disable GCC_PLUGIN_LATENT_ENTROPY
scripts/config --disable GCC_PLUGIN_RANDSTRUCT
scripts/config --disable GCC_PLUGIN_STRUCTLEAK
scripts/config --disable GCC_PLUGIN_STRUCTLEAK_BYREF
scripts/config --disable GCC_PLUGIN_STRUCTLEAK_BYREF_ALL
scripts/config --disable GCC_PLUGIN_STACKLEAK

# Avoid warnings becoming fatal.
scripts/config --disable WERROR

# Avoid compressed modules for simpler compatibility.
scripts/config --disable MODULE_COMPRESS
scripts/config --disable MODULE_COMPRESS_GZIP
scripts/config --disable MODULE_COMPRESS_XZ
scripts/config --disable MODULE_COMPRESS_ZSTD

make -j"${JOBS}" "${MAKE_ARGS[@]}" olddefconfig

echo
echo "Important final config values:"
grep -E '^(CONFIG_LOCALVERSION=|CONFIG_TCP_CONG_BBR=|CONFIG_TCP_CONG_BBR1=|CONFIG_NET_SCH_FQ=|CONFIG_DEFAULT_TCP_CONG=|CONFIG_DEFAULT_BBR=)' .config || true
echo

KVER="$(make "${MAKE_ARGS[@]}" -s kernelrelease)"
echo "Kernel release will be: $KVER"
echo "Target kernel ARCH=$KARCH"
echo "Debian package arch=$DEBARCH"
echo "CROSS_COMPILE=${CROSS_COMPILE:-<none>}"
echo "Using JOBS=$JOBS"
echo "Container sees CPUs: $(nproc || true)"

export DEB_BUILD_OPTIONS="parallel=${JOBS} nocheck"

# xz is compatible with older Debian/Ubuntu. gzip is faster if you set
# KDEB_COMPRESS=gzip.
export KDEB_COMPRESS="${KDEB_COMPRESS:-xz}"
export XZ_DEFAULTS="${XZ_DEFAULTS:--T0}"

export KDEB_SOURCENAME="linux-bbrv3"
export KDEB_CHANGELOG_DIST="stable"

KDEB_PKGVERSION="${KDEB_PKGVERSION:-1}"

make -j"${JOBS}" "${MAKE_ARGS[@]}" \
  KBUILD_DEBARCH="$DEBARCH" \
  KDEB_PKGVERSION="$KDEB_PKGVERSION" \
  bindeb-pkg

# Clean this output folder to avoid mixing old broken packages.
rm -f "$OUT"/*.deb "$OUT"/SHA256SUMS

# Copy only the packages normally needed for install.
# Skip huge/broken debug packages by default.
find .. -maxdepth 1 -type f \
  \( -name 'linux-image-*.deb' -o -name 'linux-headers-*.deb' \) \
  ! -name '*-dbg_*.deb' \
  ! -name '*-dbgsym_*.deb' \
  -exec cp -v {} "$OUT/" \;

# Optional: copy linux-libc-dev only if explicitly requested.
if [[ "${COPY_LINUX_LIBC_DEV:-0}" == "1" ]]; then
  find .. -maxdepth 1 -type f -name 'linux-libc-dev_*.deb' -exec cp -v {} "$OUT/" \;
fi

(
  cd "$OUT"
  test -n "$(find . -maxdepth 1 -name '*.deb' -print -quit)"
  sha256sum ./*.deb > SHA256SUMS
)

echo
echo "Built packages:"
ls -lh "$OUT"
