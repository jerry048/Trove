#!/usr/bin/env bash
set -Eeuo pipefail
shopt -s nullglob

# Build/run the builder container as amd64 on the Debian 13 x86_64 host.
# This is intentionally separate from the kernel target architecture below.
PLATFORM="${PLATFORM:-linux/amd64}"

# Kernel target architecture and Debian package architecture.
KARCH="${KARCH:-arm64}"
DEBARCH="${DEBARCH:-arm64}"
CROSS_COMPILE="${CROSS_COMPILE:-aarch64-linux-gnu-}"

CONFIG_DIR="${CONFIG_DIR:-configs}"
OUT_ROOT="${OUT_ROOT:-out-all}"
BUILDER_PREFIX="${BUILDER_PREFIX:-bbrv3-kernel-builder}"
LOCALVERSION_BASE="${LOCALVERSION_BASE:--bbrv3}"
PULL="${PULL:-1}"
NO_CACHE="${NO_CACHE:-0}"
CONTINUE_ON_ERROR="${CONTINUE_ON_ERROR:-0}"
AUTO_EXTRACT_CONFIGS="${AUTO_EXTRACT_CONFIGS:-0}"
BUILD_FILTER="${BUILD_FILTER:-}"

ROOT_DIR="$(pwd -P)"

case "$CONFIG_DIR" in
  /*) CONFIG_DIR_ABS="$CONFIG_DIR" ;;
  *)  CONFIG_DIR_ABS="$ROOT_DIR/$CONFIG_DIR" ;;
esac

case "$OUT_ROOT" in
  /*) OUT_ROOT_ABS="$OUT_ROOT" ;;
  *)  OUT_ROOT_ABS="$ROOT_DIR/$OUT_ROOT" ;;
esac

mkdir -p "$OUT_ROOT_ABS/logs"

if [[ ! -f "$ROOT_DIR/Dockerfile" ]]; then
  echo "ERROR: Dockerfile not found in $ROOT_DIR" >&2
  exit 1
fi

if [[ ! -f "$ROOT_DIR/build-bbrv3.sh" ]]; then
  echo "ERROR: build-bbrv3.sh not found in $ROOT_DIR" >&2
  exit 1
fi

if ! grep -qE '^ARG[[:space:]]+BASE_IMAGE' "$ROOT_DIR/Dockerfile" \
   || ! grep -qE '^FROM[[:space:]]+(\$\{BASE_IMAGE\}|\$BASE_IMAGE)' "$ROOT_DIR/Dockerfile"; then
  cat >&2 <<'MSG'
ERROR: Dockerfile does not appear to support BASE_IMAGE.

Put this at the very top of Dockerfile:

  ARG BASE_IMAGE=debian:trixie
  FROM ${BASE_IMAGE}

Then run this script again.
MSG
  exit 1
fi

# config file | matching Docker base image | output/build slug | distro kernel meta package
BUILDS=(
  "config-debian11-arm64|debian:bullseye|debian11-arm64|linux-image-arm64"
  "config-debian12-arm64|debian:bookworm|debian12-arm64|linux-image-arm64"
  "config-debian13-arm64|debian:trixie|debian13-arm64|linux-image-arm64"
  "config-ubuntu2204-arm64|ubuntu:22.04|ubuntu2204-arm64|linux-image-generic"
  "config-ubuntu2404-arm64|ubuntu:24.04|ubuntu2404-arm64|linux-image-generic"
  "config-ubuntu2604-arm64|ubuntu:26.04|ubuntu2604-arm64|linux-image-generic"
)

usage() {
  cat <<'MSG'
Usage:
  ./build-all-bbrv3.sh

Useful environment variables:
  BUILD_FILTER="debian11,ubuntu2404"  Build only matching slugs/configs/bases.
  CONTINUE_ON_ERROR=1                 Try remaining distros after a failure.
  NO_CACHE=1                          Rebuild Docker images without cache.
  AUTO_EXTRACT_CONFIGS=1              Generate missing configs automatically.
  JOBS="$(nproc)"                     Kernel build parallelism inside container.
MSG
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

slug_matches_filter() {
  local cfg="$1" base="$2" slug="$3" item haystack

  [[ -z "$BUILD_FILTER" ]] && return 0

  haystack="$cfg $base $slug"
  for item in ${BUILD_FILTER//,/ }; do
    [[ -z "$item" ]] && continue
    if [[ "$haystack" == *"$item"* ]]; then
      return 0
    fi
  done

  return 1
}

short_suffix_for_slug() {
  local slug="$1"
  case "$slug" in
    debian11-arm64)     echo "-d11-arm64" ;;
    debian12-arm64)     echo "-d12-arm64" ;;
    debian13-arm64)     echo "-d13-arm64" ;;
    ubuntu2204-arm64)   echo "-u22-arm64" ;;
    ubuntu2404-arm64)   echo "-u24-arm64" ;;
    ubuntu2604-arm64)   echo "-u26-arm64" ;;
    *)                  echo "-$slug" ;;
  esac
}

maybe_extract_config() {
  local base="$1" meta="$2" cfg="$3" cfg_path="$4"

  if [[ -f "$cfg_path" ]]; then
    return 0
  fi

  if [[ "$AUTO_EXTRACT_CONFIGS" != "1" ]]; then
    echo "ERROR: missing config: $cfg_path" >&2
    echo "Create all configs first with:" >&2
    echo "  ./extract-kernel-config.sh all" >&2
    echo "Or create just this one with:" >&2
    echo "  ./extract-kernel-config.sh '$base' '$meta' '$cfg' '$PLATFORM' '$DEBARCH'" >&2
    return 1
  fi

  if [[ ! -x "$ROOT_DIR/extract-kernel-config.sh" ]]; then
    echo "ERROR: missing executable extractor: $ROOT_DIR/extract-kernel-config.sh" >&2
    return 1
  fi

  echo "Config missing; extracting it first: $cfg"
  CONFIG_DIR="$CONFIG_DIR_ABS" \
    "$ROOT_DIR/extract-kernel-config.sh" "$base" "$meta" "$cfg" "$PLATFORM" "$DEBARCH"
}

run_one() {
  local row="$1"
  local cfg base slug meta cfg_path out_dir tag log localversion short_suffix debs

  IFS='|' read -r cfg base slug meta <<< "$row"

  cfg_path="$CONFIG_DIR_ABS/$cfg"
  out_dir="$OUT_ROOT_ABS/$slug"
  tag="$BUILDER_PREFIX:$slug"
  log="$OUT_ROOT_ABS/logs/$slug.log"
  short_suffix="$(short_suffix_for_slug "$slug")"
  localversion="${LOCALVERSION_BASE}${short_suffix}"

  maybe_extract_config "$base" "$meta" "$cfg" "$cfg_path" || return 1

  mkdir -p "$out_dir"

  echo
  echo "============================================================"
  echo "Building:        $slug"
  echo "Docker base:     $base"
  echo "Builder platform:$PLATFORM"
  echo "Kernel ARCH:     $KARCH"
  echo "Debian arch:     $DEBARCH"
  echo "Cross compiler:  $CROSS_COMPILE"
  echo "Config:          $cfg_path"
  echo "Output:          $out_dir"
  echo "Localversion:    $localversion"
  echo "Log:             $log"
  echo "============================================================"
  echo

  local build_cmd=(docker build)
  [[ -n "$PLATFORM" ]] && build_cmd+=(--platform "$PLATFORM")
  [[ "$PULL" == "1" ]] && build_cmd+=(--pull)
  [[ "$NO_CACHE" == "1" ]] && build_cmd+=(--no-cache)
  build_cmd+=(--build-arg "BASE_IMAGE=$base")
  build_cmd+=(--build-arg "TARGET_DEBARCH=$DEBARCH")
  build_cmd+=(-t "$tag")
  build_cmd+=("$ROOT_DIR")

  local run_cmd=(docker run --rm)
  [[ -n "$PLATFORM" ]] && run_cmd+=(--platform "$PLATFORM")
  run_cmd+=(
    -v "$out_dir:/out"
    -v "$cfg_path:/config/base.config:ro"
    -e CONFIG_IN=/config/base.config
    -e "KERNEL_LOCALVERSION=$localversion"
    -e "KARCH=$KARCH"
    -e "DEBARCH=$DEBARCH"
    -e "CROSS_COMPILE=$CROSS_COMPILE"
  )

  # Optional pass-throughs.
  for var in GIT_URL GIT_BRANCH JOBS KDEB_COMPRESS XZ_DEFAULTS MAKEFLAGS V KDEB_PKGVERSION COPY_LINUX_LIBC_DEV; do
    if [[ -n "${!var:-}" ]]; then
      run_cmd+=(-e "$var=${!var}")
    fi
  done

  run_cmd+=("$tag")

  {
    echo "### docker build"
    printf '%q ' "${build_cmd[@]}"
    echo
    "${build_cmd[@]}"

    echo
    echo "### docker run"
    printf '%q ' "${run_cmd[@]}"
    echo
    "${run_cmd[@]}"

    echo
    echo "### output packages"
    debs=("$out_dir"/*.deb)
    if (( ${#debs[@]} == 0 )); then
      echo "ERROR: no .deb packages produced in $out_dir" >&2
      return 1
    fi

    ls -lh "$out_dir"
  } 2>&1 | tee "$log"
}

failed=()
selected=()

for row in "${BUILDS[@]}"; do
  IFS='|' read -r cfg base slug meta <<< "$row"
  if slug_matches_filter "$cfg" "$base" "$slug"; then
    selected+=("$row")
  fi
done

if (( ${#selected[@]} == 0 )); then
  echo "ERROR: BUILD_FILTER matched no builds: $BUILD_FILTER" >&2
  exit 1
fi

for row in "${selected[@]}"; do
  IFS='|' read -r cfg base slug meta <<< "$row"

  if ! run_one "$row"; then
    failed+=("$slug")

    if [[ "$CONTINUE_ON_ERROR" != "1" ]]; then
      echo
      echo "Stopped after failure: $slug"
      echo "See log: $OUT_ROOT_ABS/logs/$slug.log"
      exit 1
    fi
  fi
done

echo
echo "============================================================"
echo "Build summary"
echo "============================================================"

for row in "${selected[@]}"; do
  IFS='|' read -r cfg base slug meta <<< "$row"
  out_dir="$OUT_ROOT_ABS/$slug"
  debs=("$out_dir"/*.deb)

  if (( ${#debs[@]} > 0 )); then
    echo
    echo "$slug:"
    ls -lh "${debs[@]}"
  fi
done

if (( ${#failed[@]} > 0 )); then
  echo
  echo "Failed builds:"
  printf '  %s\n' "${failed[@]}"
  exit 1
fi

echo
echo "All builds completed."
echo "Outputs are under: $OUT_ROOT_ABS"
