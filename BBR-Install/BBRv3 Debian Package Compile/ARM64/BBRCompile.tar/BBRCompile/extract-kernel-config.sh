#!/usr/bin/env bash
set -Eeuo pipefail

# Generates ARM64 distro kernel configs from an x86_64/amd64 builder host.
PLATFORM_DEFAULT="${PLATFORM:-linux/amd64}"
TARGET_DEBARCH_DEFAULT="${TARGET_DEBARCH:-arm64}"
CONFIG_DIR="${CONFIG_DIR:-configs}"
CONTINUE_ON_ERROR="${CONTINUE_ON_ERROR:-0}"
ROOT_DIR="$(pwd -P)"
case "$CONFIG_DIR" in
  /*) CONFIG_DIR_ABS="$CONFIG_DIR" ;;
  *)  CONFIG_DIR_ABS="$ROOT_DIR/$CONFIG_DIR" ;;
esac

CONFIG_MATRIX=(
  "debian:bullseye|linux-image-arm64|config-debian11-arm64"
  "debian:bookworm|linux-image-arm64|config-debian12-arm64"
  "debian:trixie|linux-image-arm64|config-debian13-arm64"
  "ubuntu:22.04|linux-image-generic|config-ubuntu2204-arm64"
  "ubuntu:24.04|linux-image-generic|config-ubuntu2404-arm64"
  "ubuntu:26.04|linux-image-generic|config-ubuntu2604-arm64"
)

usage() {
  cat <<'MSG'
Usage:
  ./extract-kernel-config.sh all
  ./extract-kernel-config.sh IMAGE KERNEL_META OUTFILE [PLATFORM] [TARGET_DEBARCH]

Examples:
  ./extract-kernel-config.sh all
  ./extract-kernel-config.sh debian:bookworm linux-image-arm64 config-debian12-arm64 linux/amd64 arm64
  ./extract-kernel-config.sh ubuntu:24.04 linux-image-generic config-ubuntu2404-arm64 linux/amd64 arm64
MSG
}

setup_one() {
  local image="$1"
  local kernel_meta="$2"
  local outfile="$3"
  local platform="${4:-$PLATFORM_DEFAULT}"
  local target_debarch="${5:-$TARGET_DEBARCH_DEFAULT}"

  mkdir -p "$CONFIG_DIR_ABS"

  echo
  echo "============================================================"
  echo "Extracting config: $outfile"
  echo "Docker image:      $image"
  echo "Kernel meta:       $kernel_meta"
  echo "Platform:          $platform"
  echo "Target arch:       $target_debarch"
  echo "Output dir:        $CONFIG_DIR_ABS"
  echo "============================================================"
  echo

  docker run --rm -i \
    --platform "$platform" \
    -v "$CONFIG_DIR_ABS:/out" \
    -e "KERNEL_META=$kernel_meta" \
    -e "OUTFILE=$outfile" \
    -e "TARGET_DEBARCH=$target_debarch" \
    "$image" \
    bash -euxo pipefail <<'EOS'
      export DEBIAN_FRONTEND=noninteractive

      native_arch="$(dpkg --print-architecture)"

      os_id=""
      os_codename=""
      if [ -r /etc/os-release ]; then
        . /etc/os-release
        os_id="${ID:-}"
        os_codename="${VERSION_CODENAME:-${UBUNTU_CODENAME:-}}"
      fi

      # Ubuntu keeps non-amd64 package indexes on ports.ubuntu.com. When this
      # amd64 container is used only to download ARM64 packages, replace the
      # default sources with explicit native and target-arch sources. This keeps
      # native apt tooling available and also exposes arm64 kernel packages.
      if [ "$TARGET_DEBARCH" != "$native_arch" ] && [ "$os_id" = "ubuntu" ]; then
        test -n "$os_codename"
        mkdir -p /etc/apt/sources.list.d.disabled
        for f in /etc/apt/sources.list /etc/apt/sources.list.d/*.list /etc/apt/sources.list.d/*.sources; do
          [ -e "$f" ] || continue
          mv "$f" "/etc/apt/sources.list.d.disabled/$(basename "$f").disabled"
        done

        cat > /etc/apt/sources.list.d/ubuntu-native.sources <<EOF_INNER
Types: deb
URIs: http://archive.ubuntu.com/ubuntu/
Suites: $os_codename $os_codename-updates $os_codename-backports
Components: main restricted universe multiverse
Architectures: $native_arch
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg

Types: deb
URIs: http://security.ubuntu.com/ubuntu/
Suites: $os_codename-security
Components: main restricted universe multiverse
Architectures: $native_arch
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
EOF_INNER

        cat > /etc/apt/sources.list.d/ubuntu-ports-target.sources <<EOF_INNER
Types: deb
URIs: http://ports.ubuntu.com/ubuntu-ports/
Suites: $os_codename $os_codename-updates $os_codename-backports $os_codename-security
Components: main restricted universe multiverse
Architectures: $TARGET_DEBARCH
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
EOF_INNER
      fi

      if [ "$TARGET_DEBARCH" != "$native_arch" ]; then
        dpkg --add-architecture "$TARGET_DEBARCH"
      fi

      apt-get update

      target_qualify() {
        case "$1" in
          *:*) printf '%s\n' "$1" ;;
          *)   printf '%s:%s\n' "$1" "$TARGET_DEBARCH" ;;
        esac
      }

      clean_dep_name() {
        local dep="$1"
        dep="${dep#${dep%%[![:space:]]*}}"
        dep="${dep%% *}"
        dep="${dep#<}"
        dep="${dep%>}"
        dep="${dep%%:*}"
        printf '%s\n' "$dep"
      }

      add_unique() {
        local candidate="$1"
        shift
        local existing
        for existing in "$@"; do
          [ "$existing" != "$candidate" ] || return 1
        done
        return 0
      }

      meta_pkg="$(target_qualify "$KERNEL_META")"
      echo "Resolving concrete kernel image from: $meta_pkg"

      mapfile -t depends_lines < <(apt-cache depends --no-recommends "$meta_pkg" 2>/dev/null || true)
      printf '%s\n' "${depends_lines[@]}"

      image_pkgs=()
      module_pkgs=()

      # If the caller already gave an exact versioned linux-image package, use it.
      meta_unqualified="${KERNEL_META%%:*}"
      case "$meta_unqualified" in
        linux-image-[0-9]*|linux-image-unsigned-[0-9]*)
          image_pkgs+=("$meta_unqualified")
          ;;
      esac

      for line in "${depends_lines[@]}"; do
        case "$line" in
          *Depends:*)
            dep="${line#*Depends:}"
            dep="$(clean_dep_name "$dep")"
            case "$dep" in
              linux-image-[0-9]*|linux-image-unsigned-[0-9]*)
                if add_unique "$dep" "${image_pkgs[@]}"; then image_pkgs+=("$dep"); fi
                ;;
              linux-modules-[0-9]*|linux-modules-extra-[0-9]*|linux-main-modules-[0-9]*|linux-main-modules-zfs-[0-9]*)
                if add_unique "$dep" "${module_pkgs[@]}"; then module_pkgs+=("$dep"); fi
                ;;
            esac
            ;;
        esac
      done

      # Fallback for older apt output: parse the Depends field from package metadata.
      if [ "${#image_pkgs[@]}" -eq 0 ]; then
        depends_field="$(apt-cache show "$meta_pkg" 2>/dev/null | awk -F': ' '/^Depends:/ {print $2; exit}' || true)"
        if [ -n "$depends_field" ]; then
          IFS=',' read -r -a dep_items <<< "$depends_field"
          for dep_item in "${dep_items[@]}"; do
            dep_item="${dep_item%%|*}"
            dep_item="${dep_item%%(*}"
            dep_item="$(clean_dep_name "$dep_item")"
            case "$dep_item" in
              linux-image-[0-9]*|linux-image-unsigned-[0-9]*)
                if add_unique "$dep_item" "${image_pkgs[@]}"; then image_pkgs+=("$dep_item"); fi
                ;;
              linux-modules-[0-9]*|linux-modules-extra-[0-9]*|linux-main-modules-[0-9]*|linux-main-modules-zfs-[0-9]*)
                if add_unique "$dep_item" "${module_pkgs[@]}"; then module_pkgs+=("$dep_item"); fi
                ;;
            esac
          done
        fi
      fi

      if [ "${#image_pkgs[@]}" -eq 0 ]; then
        echo "ERROR: could not resolve a concrete versioned linux-image package from $meta_pkg" >&2
        echo >&2
        echo "apt-cache policy:" >&2
        apt-cache policy "$meta_pkg" >&2 || true
        echo >&2
        echo "apt-cache depends:" >&2
        apt-cache depends "$meta_pkg" >&2 || true
        exit 1
      fi

      rm -rf /tmp/kernel-root /tmp/kernel-debs
      mkdir -p /tmp/kernel-root /tmp/kernel-debs
      cd /tmp/kernel-debs

      echo
      echo "Concrete kernel image package(s): ${image_pkgs[*]}"
      echo "Optional module package(s), only used as fallback: ${module_pkgs[*]:-<none>}"

      # Download the real kernel image package directly. Do not use
      # apt-get install/download-only here: the meta package may depend on
      # firmware packages that are intentionally unavailable as target-arch
      # packages in a mixed-architecture extraction container.
      for pkg in "${image_pkgs[@]}"; do
        qpkg="$(target_qualify "$pkg")"
        echo "Downloading kernel image package directly: $qpkg"
        apt-get download "$qpkg"
      done

      extract_downloaded_debs() {
        local deb
        shopt -s nullglob
        for deb in /tmp/kernel-debs/*.deb; do
          echo "Extracting $deb"
          dpkg-deb -x "$deb" /tmp/kernel-root
        done
      }

      find_config() {
        local cfg=""
        if compgen -G '/tmp/kernel-root/boot/config-*' >/dev/null; then
          cfg="$(find /tmp/kernel-root/boot -maxdepth 1 -type f -name 'config-*' | sort -V | tail -n1)"
        fi
        if [ -z "$cfg" ]; then
          cfg="$(find /tmp/kernel-root -type f \( -name 'config-*' -o -name '.config' \) | sort -V | tail -n1 || true)"
        fi
        printf '%s\n' "$cfg"
      }

      extract_downloaded_debs
      cfg="$(find_config)"

      # Rare fallback: if the image package did not contain /boot/config-*,
      # fetch concrete module packages directly, still without resolving the
      # whole dependency tree.
      if [ -z "$cfg" ] && [ "${#module_pkgs[@]}" -gt 0 ]; then
        for pkg in "${module_pkgs[@]}"; do
          qpkg="$(target_qualify "$pkg")"
          echo "Downloading fallback module package directly: $qpkg"
          apt-get download "$qpkg" || true
        done
        extract_downloaded_debs
        cfg="$(find_config)"
      fi

      if [ -z "$cfg" ]; then
        echo "ERROR: no kernel config found in downloaded packages" >&2
        echo "Downloaded packages were:" >&2
        ls -lh /tmp/kernel-debs >&2 || true
        exit 1
      fi

      cp "$cfg" "/out/$OUTFILE"

      echo
      echo "Copied kernel config:"
      echo "  $cfg"
      echo "to:"
      echo "  /out/$OUTFILE"
EOS
}

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
  usage
  exit 0
fi

if [[ $# -eq 0 || "${1:-}" == "all" ]]; then
  failed=()

  for row in "${CONFIG_MATRIX[@]}"; do
    IFS='|' read -r image kernel_meta outfile <<< "$row"
    if ! setup_one "$image" "$kernel_meta" "$outfile" "$PLATFORM_DEFAULT" "$TARGET_DEBARCH_DEFAULT"; then
      failed+=("$outfile")
      if [[ "$CONTINUE_ON_ERROR" != "1" ]]; then
        exit 1
      fi
    fi
  done

  if (( ${#failed[@]} > 0 )); then
    echo
    echo "Failed config extractions:"
    printf '  %s\n' "${failed[@]}"
    exit 1
  fi

  echo
  echo "All configs extracted into: $CONFIG_DIR_ABS"
  exit 0
fi

if [[ $# -lt 3 ]]; then
  usage >&2
  exit 2
fi

setup_one "$1" "$2" "$3" "${4:-$PLATFORM_DEFAULT}" "${5:-$TARGET_DEBARCH_DEFAULT}"
