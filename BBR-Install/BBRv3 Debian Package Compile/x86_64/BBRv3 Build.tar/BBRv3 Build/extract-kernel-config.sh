#!/usr/bin/env bash
set -euo pipefail

IMAGE="${1:?Docker image, e.g. ubuntu:24.04}"
KERNEL_META="${2:?Kernel meta package, e.g. linux-image-generic}"
OUTFILE="${3:?Output filename, e.g. config-ubuntu2404-generic}"
PLATFORM="${4:-linux/amd64}"

mkdir -p configs

docker run --rm \
  --platform "$PLATFORM" \
  -v "$PWD/configs:/out" \
  "$IMAGE" \
  bash -euxo pipefail -c "
    export DEBIAN_FRONTEND=noninteractive

    apt-get update

    # Download the distro kernel packages and dependencies,
    # but do not install them and do not run kernel postinst hooks.
    apt-get -y --download-only --no-install-recommends install '$KERNEL_META'

    rm -rf /tmp/kernel-root
    mkdir -p /tmp/kernel-root

    shopt -s nullglob
    for deb in /var/cache/apt/archives/*.deb; do
      echo \"Extracting \$deb\"
      dpkg-deb -x \"\$deb\" /tmp/kernel-root
    done

    cfg=\"\"

    if compgen -G '/tmp/kernel-root/boot/config-*' >/dev/null; then
      cfg=\$(find /tmp/kernel-root/boot -maxdepth 1 -type f -name 'config-*' | sort -V | tail -n1)
    fi

    if [ -z \"\$cfg\" ]; then
      cfg=\$(find /tmp/kernel-root -type f \( -name 'config-*' -o -name '.config' \) | sort -V | tail -n1 || true)
    fi

    test -n \"\$cfg\"

    cp \"\$cfg\" /out/'$OUTFILE'

    echo
    echo \"Copied kernel config:\"
    echo \"  \$cfg\"
    echo \"to:\"
    echo \"  /out/'$OUTFILE'\"
  "
