#!/usr/bin/env bash
set -Eeuo pipefail
shopt -s nullglob

PLATFORM="${PLATFORM:-linux/amd64}"
CONFIG_DIR="${CONFIG_DIR:-configs}"
OUT_ROOT="${OUT_ROOT:-out-all}"
BUILDER_PREFIX="${BUILDER_PREFIX:-bbrv3-kernel-builder}"
LOCALVERSION_BASE="${LOCALVERSION_BASE:--bbrv3}"
PULL="${PULL:-1}"
CONTINUE_ON_ERROR="${CONTINUE_ON_ERROR:-0}"

ROOT_DIR="$(pwd -P)"

case "$CONFIG_DIR" in
  /*) CONFIG_DIR_ABS="$CONFIG_DIR" ;;
  *)  CONFIG_DIR_ABS="$ROOT_DIR/$CONFIG_DIR" ;;
esac

case "$OUT_ROOT" in
  /*) OUT_ROOT_ABS="$OUT_ROOT" ;;
  *)  OUT_ROOT_ABS="$ROOT_DIR/$OUT_ROOT" ;;
esac

mkdir -p "$OUT_ROOT_ABS/logs"

if [[ ! -f "$ROOT_DIR/Dockerfile" ]]; then
  echo "ERROR: Dockerfile not found in $ROOT_DIR" >&2
  exit 1
fi

if [[ ! -f "$ROOT_DIR/build-bbrv3.sh" ]]; then
  echo "ERROR: build-bbrv3.sh not found in $ROOT_DIR" >&2
  exit 1
fi

if ! grep -qE '^ARG[[:space:]]+BASE_IMAGE' "$ROOT_DIR/Dockerfile" \
   || ! grep -qE '^FROM[[:space:]]+(\$\{BASE_IMAGE\}|\$BASE_IMAGE)' "$ROOT_DIR/Dockerfile"; then
  cat >&2 <<'MSG'
ERROR: Dockerfile does not appear to support BASE_IMAGE.

Put this at the very top of Dockerfile:

  ARG BASE_IMAGE=debian:bookworm
  FROM ${BASE_IMAGE}

Then run this script again.
MSG
  exit 1
fi


#  "config-debian11-amd64|debian:bullseye|debian11-amd64"
#  "config-debian12-amd64|debian:bookworm|debian12-amd64"
#  "config-debian13-amd64|debian:trixie|debian13-amd64"
#  "config-ubuntu2204-generic|ubuntu:22.04|ubuntu2204-generic"
#  "config-ubuntu2404-generic|ubuntu:24.04|ubuntu2404-generic"
#  "config-ubuntu2604-generic|ubuntu:26.04|ubuntu2604-generic"



# config file | matching Docker base image | output/build slug
BUILDS=(
  "config-ubuntu2604-generic|ubuntu:26.04|ubuntu2604-generic"
)

run_one() {
  local row="$1"
  local cfg base slug cfg_path out_dir tag log localversion

  IFS='|' read -r cfg base slug <<< "$row"

  cfg_path="$CONFIG_DIR_ABS/$cfg"
  out_dir="$OUT_ROOT_ABS/$slug"
  tag="$BUILDER_PREFIX:$slug"
  log="$OUT_ROOT_ABS/logs/$slug.log"
  case "$slug" in
  debian11-amd64)       short_suffix="d11" ;;
  debian12-amd64)       short_suffix="d12" ;;
  debian13-amd64)       short_suffix="d13" ;;
  ubuntu2004-generic)   short_suffix="u20" ;;
  ubuntu2204-generic)   short_suffix="u22" ;;
  ubuntu2404-generic)   short_suffix="u24" ;;
  *)                    short_suffix="$slug" ;;
esac

localversion="${LOCALVERSION_BASE}${short_suffix}"

  if [[ ! -f "$cfg_path" ]]; then
    echo "ERROR: missing config: $cfg_path" >&2
    return 1
  fi

  mkdir -p "$out_dir"

  echo
  echo "============================================================"
  echo "Building:      $slug"
  echo "Docker base:   $base"
  echo "Config:        $cfg_path"
  echo "Output:        $out_dir"
  echo "Localversion:  $localversion"
  echo "Log:           $log"
  echo "============================================================"
  echo

  local build_cmd=(docker build)
  [[ -n "$PLATFORM" ]] && build_cmd+=(--platform "$PLATFORM")
  [[ "$PULL" == "1" ]] && build_cmd+=(--pull)
  build_cmd+=(--build-arg "BASE_IMAGE=$base")
  build_cmd+=(-t "$tag")
  build_cmd+=("$ROOT_DIR")

  local run_cmd=(docker run --rm)
  [[ -n "$PLATFORM" ]] && run_cmd+=(--platform "$PLATFORM")
  run_cmd+=(
    -v "$out_dir:/out"
    -v "$cfg_path:/config/base.config:ro"
    -e CONFIG_IN=/config/base.config
    -e "KERNEL_LOCALVERSION=$localversion"
  )

  # Optional pass-throughs.
  for var in GIT_URL GIT_BRANCH JOBS KARCH DEBARCH CROSS_COMPILE KDEB_COMPRESS XZ_DEFAULTS MAKEFLAGS V; do
    if [[ -n "${!var:-}" ]]; then
      run_cmd+=(-e "$var=${!var}")
    fi
  done

  run_cmd+=("$tag")

  {
    echo "### docker build"
    printf '%q ' "${build_cmd[@]}"
    echo
    "${build_cmd[@]}"

    echo
    echo "### docker run"
    printf '%q ' "${run_cmd[@]}"
    echo
    "${run_cmd[@]}"

    echo
    echo "### output packages"
    debs=("$out_dir"/*.deb)
    if (( ${#debs[@]} == 0 )); then
      echo "ERROR: no .deb packages produced in $out_dir" >&2
      return 1
    fi

    ls -lh "$out_dir"
  } 2>&1 | tee "$log"
}

failed=()

for row in "${BUILDS[@]}"; do
  IFS='|' read -r cfg base slug <<< "$row"

  if ! run_one "$row"; then
    failed+=("$slug")

    if [[ "$CONTINUE_ON_ERROR" != "1" ]]; then
      echo
      echo "Stopped after failure: $slug"
      echo "See log: $OUT_ROOT_ABS/logs/$slug.log"
      exit 1
    fi
  fi
done

echo
echo "============================================================"
echo "Build summary"
echo "============================================================"

for row in "${BUILDS[@]}"; do
  IFS='|' read -r cfg base slug <<< "$row"
  out_dir="$OUT_ROOT_ABS/$slug"
  debs=("$out_dir"/*.deb)

  if (( ${#debs[@]} > 0 )); then
    echo
    echo "$slug:"
    ls -lh "${debs[@]}"
  fi
done

if (( ${#failed[@]} > 0 )); then
  echo
  echo "Failed builds:"
  printf '  %s\n' "${failed[@]}"
  exit 1
fi

echo
echo "All builds completed."
echo "Outputs are under: $OUT_ROOT_ABS"
